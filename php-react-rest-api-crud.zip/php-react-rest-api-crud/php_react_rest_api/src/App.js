import React, { Component } from 'react';

import ContactForm from './ContactForm';
import axios from 'axios';

//const API_URL = 'http://localhost:8080/api/contacts.php';
class App extends Component {

state = {
    users: []
  }


  // state = {
  //   contacts: []
  // }

componentDidMount() {
  const url="/api/contacts.php";
   axios.get(url).then(response => response.data)
    .then((data) => {
      this.setState({ users: data })
      console.log(this.state.users)
     }).catch((error) => {

          alert("error")      
     })
  }
  // [...]
  


  render() {
    return (
        <div>
        <ContactForm />
        

        <h1>Contact Management</h1>
        <table border='1' width='100%' >
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Country</th>
            <th>City</th>
            <th>Job</th>     
        </tr>

        {this.state.users.map((contact) => (
        <tr>
            <td>{ contact.name }</td>
            <td>{ contact.email }</td>
            <td>{ contact.country }</td>
            <td>{ contact.city }</td>
            <td>{ contact.job }</td>
        </tr>
        ))}
        </table>
        
</div>
        )





}
}
export default App;